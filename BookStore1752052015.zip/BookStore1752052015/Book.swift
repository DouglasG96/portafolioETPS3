//
//  Book.swift
//  BookStore
//
//  Created by Douglas on 8/5/20.
//  Copyright © 2020 Douglas. All rights reserved.
//
//  Douglas Ricardo Guzman Barahona
//  Carné: 17-5205-2015

import Foundation
class Book
{
    var title: String? = ""
    var author: String? = ""
    var description: String? = ""
}
