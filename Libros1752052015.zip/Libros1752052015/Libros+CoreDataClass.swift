//
//  Libros+CoreDataClass.swift
//  Libros1752052015
//
//  Created by Douglas on 16/5/20.
//  Copyright © 2020 Douglas. All rights reserved.
//

import Foundation
import CoreData

@objc(Libros)
public class Libros: NSManagedObject {

}
