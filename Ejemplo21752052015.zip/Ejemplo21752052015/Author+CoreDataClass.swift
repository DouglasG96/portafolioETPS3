//
//  Author+CoreDataClass.swift
//  Ejemplo21752052015
//
//  Created by Douglas on 9/5/20.
//  Copyright © 2020 Douglas. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData

@objc(Author)
public class Author: NSManagedObject {

}
